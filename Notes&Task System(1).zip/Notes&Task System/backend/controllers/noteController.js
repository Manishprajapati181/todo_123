﻿const Note = require("../models/Note");
const asyncHandler = require("../utils/asyncHandler");

const getNotes = asyncHandler(async (req, res) => {
  const { search = "" } = req.query;
  const query = { userId: req.user.id };

  if (search.trim()) {
    query.$or = [
      { title: { $regex: search.trim(), $options: "i" } },
      { content: { $regex: search.trim(), $options: "i" } }
    ];
  }

  const notes = await Note.find(query).sort({ createdAt: -1 });
  res.json(notes);
});

const createNote = asyncHandler(async (req, res) => {
  const { title, content } = req.body;

  if (!title || !content) {
    return res.status(400).json({ message: "Note title and content are required" });
  }

  const note = await Note.create({
    userId: req.user.id,
    title,
    content
  });

  res.status(201).json(note);
});

const updateNote = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const note = await Note.findOne({ _id: id, userId: req.user.id });

  if (!note) {
    return res.status(404).json({ message: "Note not found" });
  }

  const { title, content } = req.body;

  if (title !== undefined) note.title = title;
  if (content !== undefined) note.content = content;

  const updatedNote = await note.save();
  res.json(updatedNote);
});

const deleteNote = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const note = await Note.findOneAndDelete({ _id: id, userId: req.user.id });

  if (!note) {
    return res.status(404).json({ message: "Note not found" });
  }

  res.json({ message: "Note deleted successfully" });
});

module.exports = {
  getNotes,
  createNote,
  updateNote,
  deleteNote
};
