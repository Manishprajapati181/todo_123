﻿const Task = require("../models/Task");
const asyncHandler = require("../utils/asyncHandler");

const getTasks = asyncHandler(async (req, res) => {
  const { search = "", status = "" } = req.query;

  const query = { userId: req.user.id };

  if (status && ["pending", "completed"].includes(status)) {
    query.status = status;
  }

  if (search.trim()) {
    query.$or = [
      { title: { $regex: search.trim(), $options: "i" } },
      { description: { $regex: search.trim(), $options: "i" } }
    ];
  }

  const tasks = await Task.find(query).sort({ createdAt: -1 });
  res.json(tasks);
});

const createTask = asyncHandler(async (req, res) => {
  const { title, description = "", status = "pending", dueDate = null } = req.body;

  if (!title) {
    return res.status(400).json({ message: "Task title is required" });
  }

  const task = await Task.create({
    userId: req.user.id,
    title,
    description,
    status,
    dueDate: dueDate || null
  });

  res.status(201).json(task);
});

const updateTask = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const task = await Task.findOne({ _id: id, userId: req.user.id });

  if (!task) {
    return res.status(404).json({ message: "Task not found" });
  }

  const { title, description, status, dueDate } = req.body;

  if (title !== undefined) task.title = title;
  if (description !== undefined) task.description = description;
  if (status !== undefined) task.status = status;
  if (dueDate !== undefined) task.dueDate = dueDate || null;

  const updatedTask = await task.save();
  res.json(updatedTask);
});

const deleteTask = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const task = await Task.findOneAndDelete({ _id: id, userId: req.user.id });

  if (!task) {
    return res.status(404).json({ message: "Task not found" });
  }

  res.json({ message: "Task deleted successfully" });
});

module.exports = {
  getTasks,
  createTask,
  updateTask,
  deleteTask
};
