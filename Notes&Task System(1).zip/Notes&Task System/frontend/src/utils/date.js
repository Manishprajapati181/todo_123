﻿export const formatDate = (value) => {
  if (!value) {
    return "N/A";
  }

  const date = new Date(value);
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  }).format(date);
};

export const formatDateInput = (value) => {
  if (!value) {
    return "";
  }

  const date = new Date(value);
  const offset = date.getTimezoneOffset();
  const local = new Date(date.getTime() - offset * 60000);
  return local.toISOString().split("T")[0];
};

const startOfToday = () => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return today;
};

export const isOverdue = (task) => {
  if (!task.dueDate || task.status === "completed") {
    return false;
  }

  return new Date(task.dueDate) < startOfToday();
};

export const isDueToday = (task) => {
  if (!task.dueDate) {
    return false;
  }

  const due = new Date(task.dueDate);
  const today = new Date();

  return (
    due.getFullYear() === today.getFullYear() &&
    due.getMonth() === today.getMonth() &&
    due.getDate() === today.getDate()
  );
};

export const getTaskState = (task) => {
  if (task.status === "completed") {
    return { label: "Completed", className: "success" };
  }

  if (isOverdue(task)) {
    return { label: "Overdue", className: "danger" };
  }

  if (isDueToday(task)) {
    return { label: "Due Today", className: "warning" };
  }

  return { label: "Pending", className: "neutral" };
};
