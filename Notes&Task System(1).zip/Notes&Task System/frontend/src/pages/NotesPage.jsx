﻿import { useEffect, useState } from "react";
import api from "../api/axios";
import Layout from "../components/Layout";
import NoteForm from "../components/NoteForm";
import NoteList from "../components/NoteList";

const emptyNoteForm = {
  title: "",
  content: ""
};

const NotesPage = () => {
  const [notes, setNotes] = useState([]);
  const [noteForm, setNoteForm] = useState(emptyNoteForm);
  const [editingNoteId, setEditingNoteId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [savingNote, setSavingNote] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({ title: "", content: "" });
  const [success, setSuccess] = useState("");

  const loadNotes = async () => {
    setLoading(true);
    setError("");

    try {
      const { data } = await api.get("/notes");
      setNotes(data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load notes");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadNotes();
  }, []);

  const resetNoteForm = () => {
    setNoteForm(emptyNoteForm);
    setEditingNoteId(null);
    setFormError("");
    setFieldErrors({ title: "", content: "" });
  };

  const handleNoteSubmit = async (event) => {
    event.preventDefault();
    setFormError("");
    setError("");
    setSuccess("");

    const nextFieldErrors = {
      title: noteForm.title.trim() ? "" : "Note title is required.",
      content: noteForm.content.trim() ? "" : "Note content is required."
    };

    setFieldErrors(nextFieldErrors);

    if (nextFieldErrors.title || nextFieldErrors.content) {
      return;
    }

    setSavingNote(true);

    try {
      const isEditing = Boolean(editingNoteId);

      if (isEditing) {
        await api.put(`/notes/${editingNoteId}`, noteForm);
      } else {
        await api.post("/notes", noteForm);
      }

      setSuccess(isEditing ? "Note updated successfully." : "Note added successfully.");
      resetNoteForm();
      await loadNotes();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to save note");
    } finally {
      setSavingNote(false);
    }
  };

  const handleNoteEdit = (note) => {
    setEditingNoteId(note._id);
    setNoteForm({ title: note.title, content: note.content });
    setFormError("");
    setFieldErrors({ title: "", content: "" });
    setSuccess("");
  };

  const handleNoteDelete = async (id) => {
    if (!window.confirm("Delete this note?")) {
      return;
    }

    try {
      await api.delete(`/notes/${id}`);
      setSuccess("Note deleted successfully.");
      await loadNotes();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to delete note");
    }
  };

  const handleNoteFieldChange = (field) => (value) => {
    setNoteForm((current) => ({ ...current, [field]: value }));
    setFieldErrors((current) => ({ ...current, [field]: "" }));
    setFormError("");
    setError("");
    setSuccess("");
  };

  return (
    <Layout>
      {error ? <div className="error-banner dashboard-error">{error}</div> : null}
      {success ? <div className="success-banner dashboard-success">{success}</div> : null}

      {loading ? (
        <div className="loading-state">Loading your notes...</div>
      ) : (
        <div className="page-stack">
          <NoteForm
            form={noteForm}
            setForm={(updater) => {
              if (typeof updater === "function") {
                setNoteForm((current) => updater(current));
              } else {
                setNoteForm(updater);
              }
            }}
            onSubmit={handleNoteSubmit}
            onCancel={resetNoteForm}
            isEditing={Boolean(editingNoteId)}
            isSaving={savingNote}
            error={formError}
            fieldErrors={fieldErrors}
            onFieldChange={handleNoteFieldChange}
          />
          <NoteList notes={notes} onEdit={handleNoteEdit} onDelete={handleNoteDelete} />
        </div>
      )}
    </Layout>
  );
};

export default NotesPage;
