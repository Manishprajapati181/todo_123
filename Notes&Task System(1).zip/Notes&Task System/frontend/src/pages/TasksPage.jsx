﻿import { useEffect, useMemo, useState } from "react";
import api from "../api/axios";
import Layout from "../components/Layout";
import TaskFilters from "../components/TaskFilters";
import TaskForm from "../components/TaskForm";
import TaskList from "../components/TaskList";
import { formatDateInput, isDueToday, isOverdue } from "../utils/date";

const emptyTaskForm = {
  title: "",
  description: "",
  status: "pending",
  dueDate: ""
};

const TasksPage = () => {
  const [tasks, setTasks] = useState([]);
  const [taskForm, setTaskForm] = useState(emptyTaskForm);
  const [editingTaskId, setEditingTaskId] = useState(null);
  const [taskSearch, setTaskSearch] = useState("");
  const [taskStatus, setTaskStatus] = useState("all");
  const [loading, setLoading] = useState(true);
  const [savingTask, setSavingTask] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({ title: "" });
  const [success, setSuccess] = useState("");

  const loadTasks = async () => {
    setLoading(true);
    setError("");

    try {
      const { data } = await api.get("/tasks");
      setTasks(data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load tasks");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const filteredTasks = useMemo(() => {
    const query = taskSearch.trim().toLowerCase();

    return tasks.filter((task) => {
      const matchesSearch =
        !query || task.title.toLowerCase().includes(query) || (task.description || "").toLowerCase().includes(query);

      const matchesStatus =
        taskStatus === "all" ||
        (taskStatus === "pending" && task.status === "pending") ||
        (taskStatus === "completed" && task.status === "completed") ||
        (taskStatus === "overdue" && isOverdue(task)) ||
        (taskStatus === "due-today" && isDueToday(task));

      return matchesSearch && matchesStatus;
    });
  }, [tasks, taskSearch, taskStatus]);

  const resetTaskForm = () => {
    setTaskForm(emptyTaskForm);
    setEditingTaskId(null);
    setFormError("");
    setFieldErrors({ title: "" });
  };

  const handleTaskSubmit = async (event) => {
    event.preventDefault();
    setFormError("");
    setError("");
    setSuccess("");

    const nextFieldErrors = {
      title: taskForm.title.trim() ? "" : "Task title is required."
    };

    setFieldErrors(nextFieldErrors);

    if (nextFieldErrors.title) {
      return;
    }

    setSavingTask(true);

    try {
      const payload = { ...taskForm, dueDate: taskForm.dueDate || null };
      const isEditing = Boolean(editingTaskId);

      if (isEditing) {
        await api.put(`/tasks/${editingTaskId}`, payload);
      } else {
        await api.post("/tasks", payload);
      }

      setSuccess(isEditing ? "Task updated successfully." : "Task added successfully.");
      resetTaskForm();
      await loadTasks();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to save task");
    } finally {
      setSavingTask(false);
    }
  };

  const handleTaskEdit = (task) => {
    setEditingTaskId(task._id);
    setTaskForm({
      title: task.title,
      description: task.description || "",
      status: task.status || "pending",
      dueDate: formatDateInput(task.dueDate)
    });
    setFormError("");
    setFieldErrors({ title: "" });
    setSuccess("");
  };

  const handleTaskDelete = async (id) => {
    if (!window.confirm("Delete this task?")) {
      return;
    }

    try {
      await api.delete(`/tasks/${id}`);
      setSuccess("Task deleted successfully.");
      await loadTasks();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to delete task");
    }
  };

  const handleTaskToggle = async (task) => {
    try {
      await api.put(`/tasks/${task._id}`, {
        ...task,
        status: task.status === "completed" ? "pending" : "completed"
      });
      setSuccess("Task updated successfully.");
      await loadTasks();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to update task status");
    }
  };

  const clearTaskFilters = () => {
    setTaskSearch("");
    setTaskStatus("all");
  };

  const handleTaskFieldChange = (field) => (value) => {
    setTaskForm((current) => ({ ...current, [field]: value }));
    setFieldErrors((current) => ({ ...current, [field]: "" }));
    setFormError("");
    setError("");
    setSuccess("");
  };

  return (
    <Layout>
      {error ? <div className="error-banner dashboard-error">{error}</div> : null}
      {success ? <div className="success-banner dashboard-success">{success}</div> : null}

      {loading ? (
        <div className="loading-state">Loading your tasks...</div>
      ) : (
        <div className="page-stack">
          <TaskFilters
            search={taskSearch}
            setSearch={setTaskSearch}
            status={taskStatus}
            setStatus={setTaskStatus}
            onClear={clearTaskFilters}
          />
          <TaskForm
            form={taskForm}
            setForm={(updater) => {
              if (typeof updater === "function") {
                setTaskForm((current) => updater(current));
              } else {
                setTaskForm(updater);
              }
            }}
            onSubmit={handleTaskSubmit}
            onCancel={resetTaskForm}
            isEditing={Boolean(editingTaskId)}
            isSaving={savingTask}
            error={formError}
            fieldErrors={fieldErrors}
            onFieldChange={handleTaskFieldChange}
          />
          <TaskList
            tasks={filteredTasks}
            onEdit={handleTaskEdit}
            onDelete={handleTaskDelete}
            onToggleStatus={handleTaskToggle}
          />
        </div>
      )}
    </Layout>
  );
};

export default TasksPage;
