﻿import { useEffect, useMemo, useState } from "react";
import api from "../api/axios";
import Layout from "../components/Layout";
import { isDueToday, isOverdue } from "../utils/date";

const DashboardPage = () => {
  const [tasks, setTasks] = useState([]);
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadData = async () => {
    setLoading(true);
    setError("");

    try {
      const [tasksResponse, notesResponse] = await Promise.all([api.get("/tasks"), api.get("/notes")]);
      setTasks(tasksResponse.data);
      setNotes(notesResponse.data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const stats = useMemo(() => {
    const completed = tasks.filter((task) => task.status === "completed").length;
    const overdue = tasks.filter((task) => isOverdue(task)).length;
    const pending = tasks.length - completed;
    const dueToday = tasks.filter((task) => isDueToday(task)).length;

    return {
      totalTasks: tasks.length,
      pending,
      completed,
      overdue,
      dueToday,
      notes: notes.length
    };
  }, [tasks, notes]);

  return (
    <Layout>
      {error ? <div className="error-banner dashboard-error">{error}</div> : null}

      {loading ? (
        <div className="loading-state">Loading your summary...</div>
      ) : (
        <section className="summary-page">
          <div className="section-head summary-head">
            <div>
              <h2>Dashboard Summary</h2>
              <p className="muted">A quick snapshot of your activity across tasks and notes.</p>
            </div>
          </div>

          <section className="stats-grid summary-grid">
            <article className="stat-card"><span>Total Tasks</span><strong>{stats.totalTasks}</strong></article>
            <article className="stat-card"><span>Pending</span><strong>{stats.pending}</strong></article>
            <article className="stat-card"><span>Completed</span><strong>{stats.completed}</strong></article>
            <article className="stat-card"><span>Overdue</span><strong>{stats.overdue}</strong></article>
            <article className="stat-card"><span>Due Today</span><strong>{stats.dueToday}</strong></article>
            <article className="stat-card"><span>Notes</span><strong>{stats.notes}</strong></article>
          </section>
        </section>
      )}
    </Layout>
  );
};

export default DashboardPage;
