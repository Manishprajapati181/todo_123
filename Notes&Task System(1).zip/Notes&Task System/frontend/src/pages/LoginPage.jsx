﻿import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const LoginPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [form, setForm] = useState({ email: "", password: "" });
  const [fieldErrors, setFieldErrors] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const from = location.state?.from?.pathname || "/dashboard";

  const handleChange = (field) => (event) => {
    const value = event.target.value;
    setForm((current) => ({ ...current, [field]: value }));
    setFieldErrors((current) => ({ ...current, [field]: "" }));
    setError("");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const nextFieldErrors = {
      email: form.email.trim() ? "" : "Email is required.",
      password: form.password.trim() ? "" : "Password is required."
    };

    setFieldErrors(nextFieldErrors);
    setError("");

    if (nextFieldErrors.email || nextFieldErrors.password) {
      return;
    }

    setLoading(true);

    try {
      await login(form);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-panel hero-copy">
        <p className="eyebrow">Smart Task & Notes</p>
        <h1>Organize your day with less friction.</h1>
        <p className="muted">One workspace for secure login, task tracking, notes, and quick planning.</p>
      </div>

      <section className="auth-panel">
        <div className="section-head">
          <div>
            <h2>Welcome back</h2>
            <p className="muted">Sign in to access your dashboard.</p>
          </div>
        </div>

        <form className="stacked-form" onSubmit={handleSubmit} noValidate>
          <label className="field">
            <span>Email</span>
            <input
              type="email"
              value={form.email}
              onChange={handleChange("email")}
              placeholder="you@example.com"
            />
            {fieldErrors.email ? <small className="field-error">{fieldErrors.email}</small> : null}
          </label>
          <label className="field">
            <span>Password</span>
            <input
              type="password"
              value={form.password}
              onChange={handleChange("password")}
              placeholder="Your password"
            />
            {fieldErrors.password ? <small className="field-error">{fieldErrors.password}</small> : null}
          </label>
          {error ? <div className="error-banner">{error}</div> : null}
          <button type="submit" className="primary-button" disabled={loading}>
            {loading ? "Signing in..." : "Login"}
          </button>
        </form>

        <p className="muted auth-footer">
          New here? <Link to="/register">Create an account</Link>
        </p>
      </section>
    </div>
  );
};

export default LoginPage;
