﻿import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const RegisterPage = () => {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [fieldErrors, setFieldErrors] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (field) => (event) => {
    const value = event.target.value;
    setForm((current) => ({ ...current, [field]: value }));
    setFieldErrors((current) => ({ ...current, [field]: "" }));
    setError("");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const nextFieldErrors = {
      name: form.name.trim() ? "" : "Name is required.",
      email: form.email.trim() ? "" : "Email is required.",
      password: form.password.trim() ? "" : "Password is required."
    };

    setFieldErrors(nextFieldErrors);
    setError("");

    if (nextFieldErrors.name || nextFieldErrors.email || nextFieldErrors.password) {
      return;
    }

    setLoading(true);

    try {
      await register(form);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-panel hero-copy">
        <p className="eyebrow">Smart Task & Notes</p>
        <h1>Build your personal command center.</h1>
        <p className="muted">Track tasks, store notes, and keep everything synced with a secure JWT login.</p>
      </div>

      <section className="auth-panel">
        <div className="section-head">
          <div>
            <h2>Create account</h2>
            <p className="muted">Register to start managing your tasks and notes.</p>
          </div>
        </div>

        <form className="stacked-form" onSubmit={handleSubmit} noValidate>
          <label className="field">
            <span>Name</span>
            <input
              type="text"
              value={form.name}
              onChange={handleChange("name")}
              placeholder="Your name"
            />
            {fieldErrors.name ? <small className="field-error">{fieldErrors.name}</small> : null}
          </label>
          <label className="field">
            <span>Email</span>
            <input
              type="email"
              value={form.email}
              onChange={handleChange("email")}
              placeholder="you@example.com"
            />
            {fieldErrors.email ? <small className="field-error">{fieldErrors.email}</small> : null}
          </label>
          <label className="field">
            <span>Password</span>
            <input
              type="password"
              value={form.password}
              onChange={handleChange("password")}
              placeholder="Create a password"
            />
            {fieldErrors.password ? <small className="field-error">{fieldErrors.password}</small> : null}
          </label>
          {error ? <div className="error-banner">{error}</div> : null}
          <button type="submit" className="primary-button" disabled={loading}>
            {loading ? "Creating account..." : "Register"}
          </button>
        </form>

        <p className="muted auth-footer">
          Already registered? <Link to="/login">Login instead</Link>
        </p>
      </section>
    </div>
  );
};

export default RegisterPage;
