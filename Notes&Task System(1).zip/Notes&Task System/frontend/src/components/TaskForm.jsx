﻿const TaskForm = ({
  form,
  setForm,
  onSubmit,
  onCancel,
  isEditing,
  isSaving,
  error,
  fieldErrors,
  onFieldChange
}) => {
  const updateField = (field) => (event) => {
    const value = event.target.value;
    if (onFieldChange) {
      onFieldChange(field)(value);
      return;
    }
    setForm({ ...form, [field]: value });
  };

  return (
    <section className="panel">
      <div className="section-head">
        <div>
          <h2>{isEditing ? "Update Task" : "Add Task"}</h2>
          <p className="muted">Keep tasks short, clear, and action oriented.</p>
        </div>
      </div>
      <form className="stacked-form" onSubmit={onSubmit} noValidate>
        <label className="field">
          <span>Title</span>
          <input
            type="text"
            value={form.title}
            onChange={updateField("title")}
            placeholder="Finish assignment draft"
          />
          {fieldErrors?.title ? <small className="field-error">{fieldErrors.title}</small> : null}
        </label>
        <label className="field">
          <span>Description</span>
          <textarea
            rows="4"
            value={form.description}
            onChange={updateField("description")}
            placeholder="Add supporting details, links, or context..."
          />
        </label>
        <div className="form-row">
          <label className="field">
            <span>Status</span>
            <select value={form.status} onChange={updateField("status")}>
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>
          </label>
          <label className="field">
            <span>Due date</span>
            <input
              type="date"
              value={form.dueDate}
              onChange={updateField("dueDate")}
            />
          </label>
        </div>
        {error ? <div className="error-banner">{error}</div> : null}
        <div className="form-actions">
          <button type="submit" className="primary-button" disabled={isSaving}>
            {isSaving ? "Saving..." : isEditing ? "Update Task" : "Create Task"}
          </button>
          {isEditing ? (
            <button type="button" className="ghost-button" onClick={onCancel}>
              Cancel
            </button>
          ) : null}
        </div>
      </form>
    </section>
  );
};

export default TaskForm;
