﻿const NoteForm = ({ form, setForm, onSubmit, onCancel, isEditing, isSaving, error, fieldErrors, onFieldChange }) => {
  const updateField = (field) => (event) => {
    const value = event.target.value;
    if (onFieldChange) {
      onFieldChange(field)(value);
      return;
    }
    setForm({ ...form, [field]: value });
  };

  return (
    <section className="panel">
      <div className="section-head">
        <div>
          <h2>{isEditing ? "Update Note" : "Add Note"}</h2>
          <p className="muted">Capture ideas, reminders, and quick reference notes.</p>
        </div>
      </div>
      <form className="stacked-form" onSubmit={onSubmit} noValidate>
        <label className="field">
          <span>Title</span>
          <input
            type="text"
            value={form.title}
            onChange={updateField("title")}
            placeholder="Project ideas"
          />
          {fieldErrors?.title ? <small className="field-error">{fieldErrors.title}</small> : null}
        </label>
        <label className="field">
          <span>Content</span>
          <textarea
            rows="5"
            value={form.content}
            onChange={updateField("content")}
            placeholder="Write the note content here..."
          />
          {fieldErrors?.content ? <small className="field-error">{fieldErrors.content}</small> : null}
        </label>
        {error ? <div className="error-banner">{error}</div> : null}
        <div className="form-actions">
          <button type="submit" className="primary-button" disabled={isSaving}>
            {isSaving ? "Saving..." : isEditing ? "Update Note" : "Create Note"}
          </button>
          {isEditing ? (
            <button type="button" className="ghost-button" onClick={onCancel}>
              Cancel
            </button>
          ) : null}
        </div>
      </form>
    </section>
  );
};

export default NoteForm;
