﻿import { formatDate, getTaskState } from "../utils/date";

const TaskList = ({ tasks, onEdit, onDelete, onToggleStatus }) => {
  return (
    <section className="panel">
      <div className="section-head">
        <div>
          <h2>Your Tasks</h2>
          <p className="muted">Manage your workload with quick edits and status toggles.</p>
        </div>
      </div>
      {tasks.length === 0 ? (
        <div className="empty-state">
          <h3>No tasks found</h3>
          <p>Try creating a task or adjusting the filters above.</p>
        </div>
      ) : (
        <div className="card-grid">
          {tasks.map((task) => {
            const state = getTaskState(task);
            return (
              <article key={task._id} className="task-card">
                <div className="task-card-head">
                  <div>
                    <h3>{task.title}</h3>
                    <p className="muted">{task.description || "No description provided."}</p>
                  </div>
                  <span className={`pill ${state.className}`}>{state.label}</span>
                </div>
                <div className="meta-row">
                  <span className="meta-chip">Due: {task.dueDate ? formatDate(task.dueDate) : "Not set"}</span>
                  <span className="meta-chip">Updated: {formatDate(task.updatedAt || task.createdAt)}</span>
                </div>
                <div className="form-actions tight">
                  <button type="button" className="ghost-button compact" onClick={() => onEdit(task)}>
                    Edit
                  </button>
                  <button type="button" className="ghost-button compact" onClick={() => onToggleStatus(task)}>
                    {task.status === "completed" ? "Mark Pending" : "Mark Done"}
                  </button>
                  <button type="button" className="danger-button compact" onClick={() => onDelete(task._id)}>
                    Delete
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
};

export default TaskList;
