﻿import { NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

const Layout = ({ children }) => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
    year: "numeric"
  });

  const navItems = [
    { to: "/dashboard", label: "Dashboard" },
    { to: "/tasks", label: "Tasks" },
    { to: "/notes", label: "Notes" }
  ];

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar">
        <div>
          <p className="eyebrow">Smart Task & Notes</p>
          <h1>Workspace</h1>
          <p className="muted">Plan, track, and keep notes in one secure place.</p>
        </div>
        <div className="topbar-actions">
          <div className="welcome-card">
            <span className="welcome-label">Signed in as</span>
            <strong>{user?.name || "User"}</strong>
            <span className="welcome-subtle">{today}</span>
          </div>
          <button type="button" className="ghost-button" onClick={toggleTheme}>
            {theme === "dark" ? "Light mode" : "Dark mode"}
          </button>
          <button type="button" className="primary-button secondary" onClick={logout}>
            Logout
          </button>
        </div>
      </header>

      <nav className="workspace-nav">
        {navItems.map((item) => (
          <NavLink key={item.to} to={item.to} className={({ isActive }) => `nav-pill ${isActive ? "active" : ""}`}>
            {item.label}
          </NavLink>
        ))}
      </nav>

      <main className="content-shell">{children}</main>
    </div>
  );
};

export default Layout;
