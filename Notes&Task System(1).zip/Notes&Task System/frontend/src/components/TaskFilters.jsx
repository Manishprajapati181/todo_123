﻿const TaskFilters = ({ search, setSearch, status, setStatus, onClear }) => {
  const filterOptions = [
    { value: "all", label: "All" },
    { value: "pending", label: "Pending" },
    { value: "completed", label: "Completed" },
    { value: "overdue", label: "Overdue" },
    { value: "due-today", label: "Due Today" }
  ];

  return (
    <section className="panel">
      <div className="section-head">
        <div>
          <h2>Task Filters</h2>
          <p className="muted">Search, filter, and focus on what matters right now.</p>
        </div>
        <button type="button" className="ghost-button compact" onClick={onClear}>
          Clear filters
        </button>
      </div>
      <div className="filters-grid">
        <label className="field">
          <span>Search</span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search title or description"
          />
        </label>
        <label className="field">
          <span>Status</span>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            {filterOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
      </div>
    </section>
  );
};

export default TaskFilters;
