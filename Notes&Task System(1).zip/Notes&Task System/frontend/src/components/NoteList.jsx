﻿import { formatDate } from "../utils/date";

const NoteList = ({ notes, onEdit, onDelete }) => {
  return (
    <section className="panel">
      <div className="section-head">
        <div>
          <h2>Your Notes</h2>
          <p className="muted">Store quick reference, ideas, and important reminders.</p>
        </div>
      </div>
      {notes.length === 0 ? (
        <div className="empty-state">
          <h3>No notes yet</h3>
          <p>Create a note to keep important information close at hand.</p>
        </div>
      ) : (
        <div className="card-grid">
          {notes.map((note) => (
            <article key={note._id} className="note-card">
              <div className="task-card-head">
                <div>
                  <h3>{note.title}</h3>
                  <p className="muted note-preview">{note.content}</p>
                </div>
              </div>
              <div className="meta-row">
                <span className="meta-chip">Created: {formatDate(note.createdAt)}</span>
                <span className="meta-chip">Updated: {formatDate(note.updatedAt)}</span>
              </div>
              <div className="form-actions tight">
                <button type="button" className="ghost-button compact" onClick={() => onEdit(note)}>
                  Edit
                </button>
                <button type="button" className="danger-button compact" onClick={() => onDelete(note._id)}>
                  Delete
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
};

export default NoteList;
