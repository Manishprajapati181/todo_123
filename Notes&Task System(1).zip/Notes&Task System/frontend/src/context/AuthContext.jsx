import { createContext, useContext, useEffect, useMemo, useState } from "react";
import api from "../api/axios";

const AuthContext = createContext(null);

const loadStoredAuth = () => {
  try {
    const token = localStorage.getItem("smart-task-token");
    const user = localStorage.getItem("smart-task-user");

    return {
      token,
      user: user ? JSON.parse(user) : null
    };
  } catch {
    return { token: null, user: null };
  }
};

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(loadStoredAuth);

  useEffect(() => {
    if (auth.token) {
      localStorage.setItem("smart-task-token", auth.token);
    } else {
      localStorage.removeItem("smart-task-token");
    }

    if (auth.user) {
      localStorage.setItem("smart-task-user", JSON.stringify(auth.user));
    } else {
      localStorage.removeItem("smart-task-user");
    }
  }, [auth]);

  const login = async (credentials) => {
    const { data } = await api.post("/auth/login", credentials);
    setAuth({ token: data.token, user: data.user });
    return data;
  };

  const register = async (payload) => {
    const { data } = await api.post("/auth/register", payload);
    setAuth({ token: data.token, user: data.user });
    return data;
  };

  const logout = () => {
    setAuth({ token: null, user: null });
  };

  const value = useMemo(
    () => ({
      token: auth.token,
      user: auth.user,
      isAuthenticated: Boolean(auth.token),
      login,
      register,
      logout
    }),
    [auth.token, auth.user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }

  return context;
};
