﻿# Smart Task & Notes Management System

Full-stack MERN project for secure authentication, task CRUD, and notes CRUD.

## Project Structure

- `backend/` - Node.js, Express, MongoDB, JWT auth
- `frontend/` - React + Vite UI

## Backend Setup

1. Copy `backend/.env.example` to `backend/.env`
2. Fill in `MONGODB_URI`, `JWT_SECRET`, and `CLIENT_URL`
3. Install dependencies and start the server

```bash
cd backend
npm install
npm run dev
```

## Frontend Setup

1. Copy `frontend/.env.example` to `frontend/.env`
2. Set `VITE_API_URL` to your backend API URL
3. Install dependencies and start the app

```bash
cd frontend
npm install
npm run dev
```

## API Endpoints

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/tasks`
- `POST /api/tasks`
- `PUT /api/tasks/:id`
- `DELETE /api/tasks/:id`
- `GET /api/notes`
- `POST /api/notes`
- `PUT /api/notes/:id`
- `DELETE /api/notes/:id`

## Notes

- Tasks and notes are protected with JWT.
- MongoDB is used only in the backend layer, which the React frontend consumes through Axios.
- The dashboard includes dark mode, responsive layout, task search/filtering, due dates, and edit/delete flows.
